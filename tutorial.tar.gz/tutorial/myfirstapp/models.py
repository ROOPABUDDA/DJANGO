from django.db import models
# Create your models here.
from django.db import models
# from django.contrib.postgres.fields import JSONField

class FirstApp(models.Model):
    fname = models.CharField(maxlength=50)
    lname = models.CharField(maxlength=50)
    age = models.IntegerField(max_value=60, min_value=0)

    def display(self):
        return self.fname + self.lname, self.age
