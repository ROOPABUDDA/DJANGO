from rest_framework import serializers
from models import FirstApp


class First(serializers.ModelSerializers):
    fname = models.CharField(maxlength=50)
    lname = models.CharField(maxlength=50)
    age = models.IntegerField(max_value=60, min_value=0)

    object = FirstApp()
    object.save()


