from django.shortcuts import render
from rest_framework import viewsets
from django.contrib.auth.models import User
from .serializers import UserSerializers

# Create your views here.

class FirstAppView(viewsets.ModelViewSet):

    comment = "This ia my first app"

    def get(self, request):
        return HttpResponse(self.comment)
