from django.conf.urls import url
from myfirstapp import views


urlpattern = [
    url = (r'/firstapp', views.myfirstapp)
]
